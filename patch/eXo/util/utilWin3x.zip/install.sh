#!/usr/bin/env bash
# install.sh — eXoWin3x cross-platform game installer (Linux and macOS).
if [[ "$LD_PRELOAD" =~ "gameoverlayrenderer" ]]
then
    LD_PRELOAD=""
fi
[[ $0 == $BASH_SOURCE ]] && cd "$( dirname "$0")"
scriptDir="$(cd "$( dirname "$BASH_SOURCE")" && pwd)"
[ $# -gt 0 ] && parameterone="$1"

if [ "${BASH_VERSINFO:-0}" -lt 5 ]
then
    if [[ "$OSTYPE" == "darwin"* ]]
    then
        printf "\n\e[1;31;47mBash 5 is required.  brew install bash\e[0m\n\n"
    else
        printf "\n\e[1;31;47mThe version of bash currently running is too old.\e[0m\n\n"
        printf "Please run the \e[1;33;40minstall_dependencies.command\e[0m script.\n"
        printf "Then, follow the instructions to install the required dependencies.\n"
    fi
    read -s -n 1 -p "Press any key to abort."
    printf "\n\n"
    exit 0
fi

if [[ "$OSTYPE" == "darwin"* ]]
then
    for _p in /opt/homebrew/bin /opt/homebrew/sbin /usr/local/bin /usr/local/sbin
    do
        [[ -d "$_p" && ":$PATH:" != *":$_p:"* ]] && export PATH="$_p:$PATH"
    done
    unset _p
fi

if [[ "$OSTYPE" == "darwin"* ]]; then _SED=gsed; else _SED=sed; fi

function goto
{
    shortcutName=$1
    newPosition=$(${_SED} -n -e "/: $shortcutName$/{:a;n;p;ba};" "$scriptDir/$(basename -- "$BASH_SOURCE")" )
    eval "$newPosition"
    exit
}
alias :="goto"

conf="${folder}"

goto start && [[ $0 != $BASH_SOURCE ]] && return

: start
if [ -e ./eXoWin3x/"${gamedir}"/ ]
then
    goto dele
fi

: check
if [ -e "./eXoWin3x/${gamename}.zip" ]
then
    goto unzip
fi

: download
clear
echo ""
echo "It appears you have not downloaded this game yet."
echo ""
echo "${gamename}"
echo ""
echo "Would you like to download it?"
echo ""
while true
do
    read -p "[Y]es or [N]o " choice
    case $choice in
        [Yy]* ) errorlevel=1
                break;;
        [Nn]* ) errorlevel=2
                break;;
        *     ) printf "Invalid input.\n";;
    esac
done

[ $errorlevel == '2' ] && goto end && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '1' ] && goto dl  && [[ $0 != $BASH_SOURCE ]] && return

: dl
[ -e ./eXoWin3x/inprogress.txt ] && goto inprogress && [[ $0 != $BASH_SOURCE ]] && return
touch ./eXoWin3x/inprogress.txt
cd eXoWin3x
if command -v wget &>/dev/null
then
    wget -np -c -R "index.html*" "https://exorlp.xyz/public/eXo/eXoWin3x/Games/${gamename}.zip"
else
    curl -L -C - -o "${gamename}.zip" "https://exorlp.xyz/public/eXo/eXoWin3x/Games/${gamename}.zip"
fi
cd ..
rm -f ./eXoWin3x/inprogress.txt
clear
echo ""
if [ -e "./eXoWin3x/${gamename}.zip" ]
then
    echo "Game Downloaded Successfully"
else
    echo "There was an error downloading the game. Exiting..."
    read -s -n 1 -p "Press any key to continue..."
    printf "\n\n"
    goto end && [[ $0 != $BASH_SOURCE ]] && return
fi
goto unzip && [[ $0 != $BASH_SOURCE ]] && return

: unzip
cd eXoWin3x
unzip -o "${gamename}.zip"
cd ..
goto config && [[ $0 != $BASH_SOURCE ]] && return

: dele
clear
echo ""
echo "This game is already installed."
echo ""
echo "Would you like to [R]einstall, [U]ninstall, or [C]ancel?"
echo ""
while true
do
    read -p "[R/U/C]? " choice
    case $choice in
        [Rr]* ) errorlevel=1
                break;;
        [Uu]* ) errorlevel=2
                break;;
        [Cc]* ) errorlevel=3
                break;;
        *     ) printf "Invalid input.\n";;
    esac
done

[ $errorlevel == '3' ] && goto end           && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '2' ] && goto erase         && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '1' ] && goto erase_reinstall && [[ $0 != $BASH_SOURCE ]] && return

: erase_reinstall
rm -rf ./eXoWin3x/"${gamedir}"/
goto check && [[ $0 != $BASH_SOURCE ]] && return

: config
clear
echo ""
echo "Would you like to enable Aspect Correction?"
echo ""
while true
do
    read -p "[Y]es or [N]o " choice
    case $choice in
        [Yy]* ) errorlevel=1
                break;;
        [Nn]* ) errorlevel=2
                break;;
        *     ) printf "Invalid input.\n";;
    esac
done

[ $errorlevel == '2' ] && goto aspect2 && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '1' ] && goto aspect  && [[ $0 != $BASH_SOURCE ]] && return

: aspect
_conf_file="${conf}/dosbox_linux.conf"
[ ! -e "$_conf_file" ] && _conf_file="${conf}/dosbox.conf"
${_SED} -i "s|aspect=false|aspect=true|g" "$_conf_file"
goto next && [[ $0 != $BASH_SOURCE ]] && return

: aspect2
_conf_file="${conf}/dosbox_linux.conf"
[ ! -e "$_conf_file" ] && _conf_file="${conf}/dosbox.conf"
${_SED} -i "s|aspect=true|aspect=false|g" "$_conf_file"

: next
clear
echo ""
echo "Would you like [F]ullscreen or [W]indowed?"
echo ""
while true
do
    read -p "[F/W]? " choice
    case $choice in
        [Ff]* ) errorlevel=1
                break;;
        [Ww]* ) errorlevel=2
                break;;
        *     ) printf "Invalid input.\n";;
    esac
done

[ $errorlevel == '2' ] && goto wind && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '1' ] && goto full && [[ $0 != $BASH_SOURCE ]] && return

: wind
_conf_file="${conf}/dosbox_linux.conf"; [ ! -e "$_conf_file" ] && _conf_file="${conf}/dosbox.conf"
${_SED} -i "s|fullscreen=true|fullscreen=false|g" "$_conf_file"
goto scaler1 && [[ $0 != $BASH_SOURCE ]] && return

: full
_conf_file="${conf}/dosbox_linux.conf"; [ ! -e "$_conf_file" ] && _conf_file="${conf}/dosbox.conf"
${_SED} -i "s|fullscreen=false|fullscreen=true|g" "$_conf_file"
goto scaler1 && [[ $0 != $BASH_SOURCE ]] && return

: scaler1
clear
echo ""
echo "Would you like to change your graphics scaler/filter?"
echo ""
while true
do
    read -p "[Y]es or [N]o " choice
    case $choice in
        [Yy]* ) errorlevel=1
                break;;
        [Nn]* ) errorlevel=2
                break;;
        *     ) printf "Invalid input.\n";;
    esac
done

[ $errorlevel == '2' ] && goto end && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '1' ] && goto sy  && [[ $0 != $BASH_SOURCE ]] && return

: sy
clear
echo ""
echo "Press 1 for no scaler"
echo "Press 2 for normal3x"
echo "Press 3 for hq2x"
echo "Press 4 for hq3x"
echo "Press 5 for 2xsai"
echo "Press 6 for super2xsai"
echo "press 7 for advmame2x"
echo "press 8 for advmame3x"
echo "press 9 for tv2x"
echo "Press 0 for normal2x"
echo ""
while true
do
    read -p "Please choose (0-9): " choice
    case $choice in
        [1] ) errorlevel=1;  break;;
        [2] ) errorlevel=2;  break;;
        [3] ) errorlevel=3;  break;;
        [4] ) errorlevel=4;  break;;
        [5] ) errorlevel=5;  break;;
        [6] ) errorlevel=6;  break;;
        [7] ) errorlevel=7;  break;;
        [8] ) errorlevel=8;  break;;
        [9] ) errorlevel=9;  break;;
        [0] ) errorlevel=10; break;;
        *   ) printf "Invalid input.\n";;
    esac
done

[ $errorlevel == '10' ] && goto normal2x && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '9'  ] && goto scaltv2x && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '8'  ] && goto scalam3x && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '7'  ] && goto scalam2x && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '6'  ] && goto scals2xs && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '5'  ] && goto scal2xs  && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '4'  ] && goto scalhq3x && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '3'  ] && goto scalhq2x && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '2'  ] && goto scaln3x  && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '1'  ] && goto scalno   && [[ $0 != $BASH_SOURCE ]] && return

: scalno
sc=none;       goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scaln3x
sc=normal3x;   goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scalhq2x
sc=hq2x;       goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scalhq3x
sc=hq3x;       goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scal2xs
sc=2xsai;      goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scals2xs
sc=super2xsai; goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scalam2x
sc=advmame2x;  goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scalam3x
sc=advmame3x;  goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: scaltv2x
sc=tv2x;       goto scaler && [[ $0 != $BASH_SOURCE ]] && return
: normal2x
sc=normal2x

: scaler
_conf_file="${conf}/dosbox_linux.conf"; [ ! -e "$_conf_file" ] && _conf_file="${conf}/dosbox.conf"
for _s in none normal3x hq2x hq3x 2xsai super2xsai advmame2x advmame3x tv2x normal2x
do
    ${_SED} -i "s|scaler=${_s}|scaler=${sc}|g" "$_conf_file"
done
goto end && [[ $0 != $BASH_SOURCE ]] && return

: erase
rm -rf ./eXoWin3x/"${gamedir}"/
goto end && [[ $0 != $BASH_SOURCE ]] && return

: inprogress
clear
echo ""
echo "A download is already in progress. Please wait for it to finish."
echo ""
read -s -n 1 -p "Press any key to continue..."
printf "\n\n"

: end
[[ $0 != $BASH_SOURCE ]] && return
