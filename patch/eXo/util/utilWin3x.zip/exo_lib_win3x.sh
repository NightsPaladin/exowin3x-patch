#!/usr/bin/env bash
# exo_lib_win3x.sh — Shared macOS helpers for eXoWin3x.
# Source this file from launch.sh on macOS; do not execute directly.

# ── Homebrew PATH ─────────────────────────────────────────────────────────────
for _p in /opt/homebrew/bin /opt/homebrew/sbin /usr/local/bin /usr/local/sbin
do
    [[ -d "$_p" && ":$PATH:" != *":$_p:"* ]] && export PATH="$_p:$PATH"
done
unset _p

# ── Root detection ────────────────────────────────────────────────────────────
WIN3X_UTIL="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WIN3X_EXO="$(cd "$WIN3X_UTIL/.." && pwd)"
WIN3X_ROOT="$(cd "$WIN3X_EXO/.." && pwd)"
WIN3X_DIR="$WIN3X_EXO/eXoWin3x"

# ── Bash version guard ────────────────────────────────────────────────────────
if [[ "${BASH_VERSINFO[0]:-0}" -lt 5 ]]; then
    printf "\n\033[1;31;47mBash 5+ required. Install via Homebrew: brew install bash\033[0m\n\n"
    exit 1
fi

# ── Dependency check ──────────────────────────────────────────────────────────
function win3x_check_deps {
    [[ "$OSTYPE" != "darwin"* ]] && return 0
    local missing=()
    for t in dosbox-staging gsed curl python3 unzip wget; do
        command -v "$t" &>/dev/null || missing+=("$t")
    done
    if [[ "${#missing[@]}" -gt 0 ]]; then
        printf "\n\033[1;31;47mMissing: %s\033[0m\n\n" "${missing[*]}"
        printf "Install: brew install %s\n\n" "${missing[*]}"
        exit 1
    fi
}

# ── DOSBox lookup (macOS) ─────────────────────────────────────────────────────
# Sets WIN3X_DOSBOX to the command for the given game name.
function win3x_find_dosbox {
    local name="$1"
    local entry=""
    entry=$(grep -i "^${name}" "$WIN3X_UTIL/dosbox_macos.txt" 2>/dev/null | tail -1 | tr -d '\r')
    WIN3X_DOSBOX="${entry#*:}"
    WIN3X_DOSBOX="${WIN3X_DOSBOX#*:}"
    [[ -z "$WIN3X_DOSBOX" ]] && WIN3X_DOSBOX="dosbox-staging"
}
