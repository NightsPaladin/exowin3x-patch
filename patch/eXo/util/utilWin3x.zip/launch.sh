#!/usr/bin/env bash
# launch.sh — eXoWin3x cross-platform game launcher (Linux and macOS).
# Sourced (not executed directly) from per-game .sh scripts.
if [[ "$LD_PRELOAD" =~ "gameoverlayrenderer" ]]
then
    LD_PRELOAD=""
fi
[[ $0 == $BASH_SOURCE ]] && cd "$( dirname "$0")"
scriptDir="$(cd "$( dirname "$BASH_SOURCE")" && pwd)"

if [ "${BASH_VERSINFO:-0}" -lt 5 ]
then
    if [[ "$OSTYPE" == "darwin"* ]]
    then
        printf "\n\e[1;31;47mBash 5 is required.  brew install bash\e[0m\n\n"
    else
        printf "\n\e[1;31;47mThe version of bash currently running is too old.\e[0m\n\n"
        printf "Please run the \e[1;33;40minstall_dependencies.command\e[0m script.\n"
        printf "Then, follow the instructions to install the required dependencies.\n"
    fi
    read -s -n 1 -p "Press any key to abort."
    printf "\n\n"
    exit 0
fi

if [[ "$OSTYPE" == "darwin"* ]]
then
    for _p in /opt/homebrew/bin /opt/homebrew/sbin /usr/local/bin /usr/local/sbin
    do
        [[ -d "$_p" && ":$PATH:" != *":$_p:"* ]] && export PATH="$_p:$PATH"
    done
    unset _p
fi

if [[ "$OSTYPE" == "darwin"* ]]; then _SED=gsed; else _SED=sed; fi

declare -a scriptDirStack

function goto
{
    shortcutName=$1
    newPosition=$(${_SED} -n -e "/: $shortcutName$/{:a;n;p;ba};" "$scriptDir/$(basename -- "$BASH_SOURCE")" )
    eval "$newPosition"
    exit
}
alias :="goto"

# Apply global display-preference overrides from SEL files
if [[ "$OSTYPE" == "darwin"* ]]
then
    [ -e ./util/AYES.SEL ] && gsed -i "s|aspect=false|aspect=true|g"   ./emulators/dosbox/options_macos.conf
    [ -e ./util/ANO.SEL ]  && gsed -i "s|aspect=true|aspect=false|g"   ./emulators/dosbox/options_macos.conf
    [ -e ./util/FULL.SEL ] && gsed -i "s|fullscreen=false|fullscreen=true|g"  ./emulators/dosbox/options_macos.conf
    [ -e ./util/WIN.SEL ]  && gsed -i "s|fullscreen=true|fullscreen=false|g"  ./emulators/dosbox/options_macos.conf
    [ -e ./util/SML.SEL ]  && gsed -i "s|windowresolution=1280x960|windowresolution=640x480|g"   ./emulators/dosbox/options_macos.conf
    [ -e ./util/SML.SEL ]  && gsed -i "s|windowresolution=2560x1920|windowresolution=640x480|g"  ./emulators/dosbox/options_macos.conf
    [ -e ./util/MED.SEL ]  && gsed -i "s|windowresolution=640x480|windowresolution=1280x960|g"   ./emulators/dosbox/options_macos.conf
    [ -e ./util/MED.SEL ]  && gsed -i "s|windowresolution=2560x1920|windowresolution=1280x960|g" ./emulators/dosbox/options_macos.conf
    [ -e ./util/LRG.SEL ]  && gsed -i "s|windowresolution=640x480|windowresolution=2560x1920|g"  ./emulators/dosbox/options_macos.conf
    [ -e ./util/LRG.SEL ]  && gsed -i "s|windowresolution=1280x960|windowresolution=2560x1920|g" ./emulators/dosbox/options_macos.conf
else
    [ -e ./util/AYES.SEL ] && sed -i -e "s|aspect=false|aspect=true|g" ./emulators/dosbox/options_linux.conf
    [ -e ./util/ANO.SEL ]  && sed -i -e "s|aspect=true|aspect=false|g" ./emulators/dosbox/options_linux.conf
    [ -e ./util/FULL.SEL ] && sed -i -e "s|fullscreen=false|fullscreen=true|g" ./emulators/dosbox/options_linux.conf
    [ -e ./util/WIN.SEL ]  && sed -i -e "s|fullscreen=true|fullscreen=false|g" ./emulators/dosbox/options_linux.conf
    [ -e ./util/SML.SEL ]  && sed -i -e "s|windowresolution=1280x960|windowresolution=640x480|g"   ./emulators/dosbox/options_linux.conf
    [ -e ./util/SML.SEL ]  && sed -i -e "s|windowresolution=2560x1920|windowresolution=640x480|g"  ./emulators/dosbox/options_linux.conf
    [ -e ./util/MED.SEL ]  && sed -i -e "s|windowresolution=640x480|windowresolution=1280x960|g"   ./emulators/dosbox/options_linux.conf
    [ -e ./util/MED.SEL ]  && sed -i -e "s|windowresolution=2560x1920|windowresolution=1280x960|g" ./emulators/dosbox/options_linux.conf
    [ -e ./util/LRG.SEL ]  && sed -i -e "s|windowresolution=640x480|windowresolution=2560x1920|g"  ./emulators/dosbox/options_linux.conf
    [ -e ./util/LRG.SEL ]  && sed -i -e "s|windowresolution=1280x960|windowresolution=2560x1920|g" ./emulators/dosbox/options_linux.conf
fi

goto english && [[ $0 != $BASH_SOURCE ]] && return

: english
[ ! -e ./eXoWin3x/"${gamedir}"/ ] && goto none && [[ $0 != $BASH_SOURCE ]] && return

: launch
if [[ "$OSTYPE" == "darwin"* ]]
then
    dosindex=$(grep -i "^${gamename}" ./util/dosbox_macos.txt 2>/dev/null | tail -1 | tr -d '\r')
    dosbox="${dosindex#*:}"
    dosbox="${dosbox#*:}"
    [ -z "$dosbox" ] && dosbox="dosbox-staging"
else
    dosindex=`grep -i "^${gamename}" ./util/dosbox_linux.txt 2>/dev/null | tail -1 | tr -d "\r"`
    dosbox1="${dosindex#*:}"
    dosbox="${dosbox1#*:}"
    [ -z "$dosbox" ] && dosbox="flatpak run com.retro_exo.dosbox-ece-r4482"
fi

: start
clear
local_conf="${var}/dosbox_linux.conf"
[ ! -e "$local_conf" ] && local_conf="${var}/dosbox.conf"
if [[ "$OSTYPE" == "darwin"* ]]
then
    [ -e "${var}/dosbox2_linux.conf" ] && local_conf="${var}/dosbox2_linux.conf"
    [ ! -e "${var}/dosbox2_linux.conf" ] && [ -e "${var}/dosbox2.conf" ] && local_conf="${var}/dosbox2.conf"
    read -ra _dosbox_cmd <<< "$dosbox"
    "${_dosbox_cmd[@]}" \
        -conf "${local_conf}" \
        -conf "./emulators/dosbox/options_macos.conf" \
        -nomenu -noconsole
else
    [ -e "${var}/dosbox2_linux.conf" ] && local_conf="${var}/dosbox2_linux.conf"
    eval "$(echo "${dosbox}" | sed -e "s/\\$/\\\\$/g")" \
        -conf "\"$(echo "${local_conf}" | sed -e "s/\\$/\\\\$/g")\"" \
        -conf "\"./emulators/dosbox/options_linux.conf\"" \
        -nomenu -noconsole
fi
rm -f stdout.txt stderr.txt
[[ "$(ls -1 glide.* 2>/dev/null | wc -l)" -gt 0 ]] && rm -f glide.*
[ -e ./eXoWin3x/CWSDPMI.swp ] && rm -f ./eXoWin3x/CWSDPMI.swp
goto end && [[ $0 != $BASH_SOURCE ]] && return

: none
clear
echo ""
echo "Game has not been installed"
echo ""
echo ""
echo "Would you like to install the game?"
echo ""
while true
do
    read -p "(y/n)? " choice
    case $choice in
        [Yy]* ) errorlevel=1
                break;;
        [Nn]* ) errorlevel=2
                break;;
        *     ) printf "Invalid input.\n";;
    esac
done

[ $errorlevel == '2' ] && goto no  && [[ $0 != $BASH_SOURCE ]] && return
[ $errorlevel == '1' ] && goto yes && [[ $0 != $BASH_SOURCE ]] && return

: yes
cd "${var}"
scriptDirStack["${#scriptDirStack[@]}"]="$scriptDir"
eval source install.sh
scriptDir="${scriptDirStack["${#scriptDirStack[@]}"-1]}"
unset scriptDirStack["${#scriptDirStack[@]}"-1]
function goto
{
    shortcutName=$1
    newPosition=$(${_SED} -n -e "/: $shortcutName$/{:a;n;p;ba};" "$scriptDir/$(basename -- "$BASH_SOURCE")" )
    eval "$newPosition"
    exit
}
cd ..
clear
goto launch && [[ $0 != $BASH_SOURCE ]] && return

: no
goto end && [[ $0 != $BASH_SOURCE ]] && return

: end
[[ $0 != $BASH_SOURCE ]] && return
