#!/usr/bin/env bash
# launch_helper.sh — Cross-platform GUI bridge for eXoWin3x.
# Usage: launch_helper.sh <gamedir> <gamename>
#
# Sets context vars from CLI args then sources the platform-appropriate launcher.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "$OSTYPE" == "darwin"* ]]; then
    source "$SCRIPT_DIR/exo_lib_win3x.sh"
fi

gamedir="$1"
gamename="$2"
indexname="${gamename::-7}"

if [[ "$OSTYPE" == "darwin"* ]]; then
    var="$WIN3X_DIR/!win3x/$gamedir"
    cd "$WIN3X_EXO"
else
    WIN3X_EXO="$(cd "$SCRIPT_DIR/.." && pwd)"
    var="$WIN3X_EXO/eXoWin3x/!win3x/$gamedir"
    cd "$WIN3X_EXO"
fi

export gamedir gamename indexname var

source "$SCRIPT_DIR/launch.sh"
