#!/usr/bin/env bash
# AltLauncher.sh — eXoWin3x cross-platform alternate launcher (Linux and macOS).
if [[ "$LD_PRELOAD" =~ "gameoverlayrenderer" ]]
then
    LD_PRELOAD=""
fi
[[ $0 == $BASH_SOURCE ]] && cd "$( dirname "$0")"
scriptDir="$(cd "$( dirname "$BASH_SOURCE")" && pwd)"

if [ "${BASH_VERSINFO:-0}" -lt 5 ]
then
    if [[ "$OSTYPE" == "darwin"* ]]
    then
        printf "\n\e[1;31;47mBash 5 is required.  brew install bash\e[0m\n\n"
    else
        printf "\n\e[1;31;47mThe version of bash currently running is too old.\e[0m\n\n"
        printf "Please run the \e[1;33;40minstall_dependencies.command\e[0m script.\n"
        printf "Then, follow the instructions to install the required dependencies.\n"
    fi
    read -s -n 1 -p "Press any key to abort."
    printf "\n\n"
    exit 0
fi

if [[ "$OSTYPE" == "darwin"* ]]
then
    for _p in /opt/homebrew/bin /opt/homebrew/sbin /usr/local/bin /usr/local/sbin
    do
        [[ -d "$_p" && ":$PATH:" != *":$_p:"* ]] && export PATH="$_p:$PATH"
    done
    unset _p
fi

if [[ "$OSTYPE" == "darwin"* ]]; then _SED=gsed; else _SED=sed; fi

function goto
{
    shortcutName=$1
    newPosition=$(${_SED} -n -e "/: $shortcutName$/{:a;n;p;ba};" "$scriptDir/$(basename -- "$BASH_SOURCE")" )
    eval "$newPosition"
    exit
}
alias :="goto"

goto english && [[ $0 != $BASH_SOURCE ]] && return

: english
[ ! -e ./eXoWin3x/"${gamedir}"/ ] && goto none && [[ $0 != $BASH_SOURCE ]] && return

: launch
if [[ "$OSTYPE" == "darwin"* ]]
then
    dosindex=$(grep -i "^${gamename}" ./util/dosbox_macos.txt 2>/dev/null | tail -1 | tr -d '\r')
    dosbox="${dosindex#*:}"; dosbox="${dosbox#*:}"
    [ -z "$dosbox" ] && dosbox="dosbox-staging"
else
    dosindex=`grep -i "^${gamename}" ./util/dosbox_linux.txt 2>/dev/null | tail -1 | tr -d "\r"`
    dosbox1="${dosindex#*:}"
    dosbox="${dosbox1#*:}"
    [ -z "$dosbox" ] && dosbox="flatpak run com.retro_exo.dosbox-ece-r4482"
fi

clear
local_conf="${var}/dosbox_linux.conf"
[ ! -e "$local_conf" ] && local_conf="${var}/dosbox.conf"
if [[ "$OSTYPE" == "darwin"* ]]
then
    read -ra _cmd <<< "$dosbox"
    "${_cmd[@]}" -conf "${local_conf}" -conf "./emulators/dosbox/options_macos.conf" -nomenu -noconsole
else
    [ -e "${var}/dosbox2_linux.conf" ] && local_conf="${var}/dosbox2_linux.conf"
    eval "$(echo "${dosbox}" | sed -e "s/\\$/\\\\$/g")" \
        -conf "\"$(echo "${local_conf}" | sed -e "s/\\$/\\\\$/g")\"" \
        -conf "\"./emulators/dosbox/options_linux.conf\"" \
        -nomenu -noconsole
fi
rm -f stdout.txt stderr.txt
[[ "$(ls -1 glide.* 2>/dev/null | wc -l)" -gt 0 ]] && rm -f glide.*
[ -e ./eXoWin3x/CWSDPMI.swp ] && rm -f ./eXoWin3x/CWSDPMI.swp
goto end && [[ $0 != $BASH_SOURCE ]] && return

: none
clear
echo ""
echo "Game has not been installed. Please run the install script first."
echo ""
read -s -n 1 -p "Press any key to continue..."
printf "\n\n"

: end
[[ $0 != $BASH_SOURCE ]] && return
